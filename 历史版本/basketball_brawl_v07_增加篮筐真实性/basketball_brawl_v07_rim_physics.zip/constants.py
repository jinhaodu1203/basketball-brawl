"""2D 篮球大乱斗 Demo 的全局配置常量。"""

SCREEN_WIDTH = 960
SCREEN_HEIGHT = 540
FPS = 60
GROUND_Y = 480

COLOR_BG = (30, 30, 40)
COLOR_GROUND = (60, 60, 70)
COLOR_PLAYER1 = (70, 130, 220)
COLOR_PLAYER2 = (220, 90, 70)
COLOR_BALL = (240, 160, 40)
COLOR_HOOP = (230, 230, 230)
COLOR_TEXT = (255, 255, 255)
COLOR_DASH_TRAIL = (255, 255, 255)

GRAVITY = 0.6
JUMP_VELOCITY = -14
MOVE_SPEED = 5
BALL_BOUNCE_DAMPING = 0.6

# 篮板与篮筐碰撞
RIM_COLLISION_RADIUS = 6
RIM_BOUNCE_DAMPING = 0.72
BACKBOARD_BOUNCE_DAMPING = 0.68
BACKBOARD_THICKNESS = 6

PLAYER_WIDTH = 46
PLAYER_HEIGHT = 68
STEAL_RANGE = 55
POSSESSION_COOLDOWN_FRAMES = 45
STEAL_COOLDOWN_FRAMES = 30

# 仅作为没有角色配置时的默认值；DJH 的 Dash 参数以 characters.py 为准。
DASH_SPEED = 14
DASH_DURATION_FRAMES = 10
DASH_COOLDOWN_FRAMES = 180

BALL_RADIUS = 12
SHOT_FLIGHT_FRAMES = 40

# ---------- 蓄力投篮 ----------
# 真人玩家长按投篮键蓄力，松开后出手。角色可在 characters.py 中覆盖这些值。
SHOT_CHARGE_MAX_FRAMES = 72
SHOT_PERFECT_MIN = 0.45
SHOT_PERFECT_MAX = 0.65
SHOT_MAX_HORIZONTAL_ERROR = 105
SHOT_METER_WIDTH = 64
SHOT_METER_HEIGHT = 7
SHOT_METER_COLOR = (235, 190, 55)
SHOT_METER_PERFECT_COLOR = (80, 220, 110)
SHOT_METER_BG_COLOR = (60, 60, 70)

BACKBOARD_X = 26
RIM_STICK_OUT = 46
RIM_X = BACKBOARD_X + RIM_STICK_OUT
RIM_Y = GROUND_Y - 210
HOOP_WIDTH = 46
HOOP_HEIGHT = 14
HOOP_X = RIM_X - HOOP_WIDTH // 2
HOOP_Y = RIM_Y - HOOP_HEIGHT // 2
BACKBOARD_HEIGHT = 90
BACKBOARD_TOP_Y = RIM_Y - BACKBOARD_HEIGHT * 0.65

COLOR_COURT_LINE = (235, 235, 245)
COLOR_PAINT_FILL = (55, 70, 95)
COURT_LINE_WIDTH = 3
PAINT_WIDTH = 150
PAINT_BAND_HEIGHT = 120
FREE_THROW_LINE_X = PAINT_WIDTH
FREE_THROW_CIRCLE_RADIUS = 45
COURT_BAND_CENTER_Y_OFFSET = 60
TWO_POINT_RADIUS = 210
THREE_POINT_RADIUS = 340
COURT_LINE_FLATTEN = 0.30
HALF_COURT_X = SCREEN_WIDTH // 2

PLAYER1_SPAWN_X = 560
PLAYER2_SPAWN_X = 760
BALL_SPAWN_X = 640

ANIMATION_SPEED = 8
DEFAULT_FRAME_COUNTS = {"idle": 2, "run": 2, "jump": 1}
BALL_SPRITE_FRAME_COUNT = 3
BALL_STATE_TO_FRAME = {"held": 0, "flying": 1, "loose": 2}

POINTS_OUTSIDE_THREE = 2
POINTS_ON_OR_INSIDE_THREE = 1
WINNING_SCORE = 12

SCORE_POPUP_DURATION_FRAMES = 90
ROUND_RESET_DELAY_FRAMES = 75
SCORE_POPUP_COLOR = (255, 215, 0)

AI_SHOOT_STOP_DISTANCE = 20
AI_TWO_POINT_SHOOT_OFFSET = 130
AI_THREE_POINT_SHOOT_MARGIN = 40
AI_THREE_POINT_SHOT_CHANCE = 0.25
AI_SHOT_MISS_CHANCE = 0.3
AI_SHOT_MISS_OFFSET = 30
AI_STEAL_APPROACH_DISTANCE = 30
AI_REBOUND_JUMP_RANGE = 60
AI_DASH_TRIGGER_CHANCE = 0.02

AI_DIFFICULTY_PRESETS = {
    "easy": {
        "move_speed_multiplier": 0.75,
        "dash_speed_multiplier": 0.75,
        "dash_cooldown_multiplier": 1.6,
        "steal_range_multiplier": 0.75,
        "shot_miss_chance": 0.6,
        "dash_trigger_chance": 0.01,
        "three_point_shot_chance": 0.10,
    },
    "normal": {
        "move_speed_multiplier": 1.0,
        "dash_speed_multiplier": 1.0,
        "dash_cooldown_multiplier": 1.0,
        "steal_range_multiplier": 1.0,
        "shot_miss_chance": AI_SHOT_MISS_CHANCE,
        "dash_trigger_chance": AI_DASH_TRIGGER_CHANCE,
        "three_point_shot_chance": AI_THREE_POINT_SHOT_CHANCE,
    },
    "hard": {
        "move_speed_multiplier": 1.3,
        "dash_speed_multiplier": 1.25,
        "dash_cooldown_multiplier": 0.55,
        "steal_range_multiplier": 1.3,
        "shot_miss_chance": 0.08,
        "dash_trigger_chance": 0.06,
        "three_point_shot_chance": 0.35,
    },
}

AI_DIFFICULTY_LABELS = {
    "easy": "EZ PZ",
    "normal": "Normal",
    "hard": "Hard as Hell",
}
