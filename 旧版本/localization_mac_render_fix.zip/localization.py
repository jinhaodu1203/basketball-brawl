"""JSON localization and robust cross-platform font helpers.

macOS/Pygame can occasionally render some TTC system fonts as solid blocks at
specific point sizes.  To avoid that, this module renders through a known-safe
base size and scales the resulting surface when needed.
"""

from __future__ import annotations

import json
import os
from typing import Any

import pygame

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_LANG_DIR = os.path.join(_BASE_DIR, "lang")
_DEFAULT_LANGUAGE = "en"
_SUPPORTED = ("en", "zh")
_language = _DEFAULT_LANGUAGE
_strings: dict[str, Any] = {}
_fallback: dict[str, Any] = {}
_SAFE_BASE_SIZE = 30


def _load_file(language: str) -> dict[str, Any]:
    path = os.path.join(_LANG_DIR, f"{language}.json")
    try:
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def set_language(language: str) -> str:
    global _language, _strings, _fallback
    normalized = language if language in _SUPPORTED else _DEFAULT_LANGUAGE
    _fallback = _load_file(_DEFAULT_LANGUAGE)
    _strings = _load_file(normalized)
    _language = normalized
    return normalized


def get_language() -> str:
    return _language


def supported_languages() -> tuple[str, ...]:
    return _SUPPORTED


def _lookup(key: str, source: dict[str, Any]) -> Any:
    current: Any = source
    for part in key.split("."):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]
    return current


def tr(key: str, **values: Any) -> str:
    text = _lookup(key, _strings)
    if text is None:
        text = _lookup(key, _fallback)
    if not isinstance(text, str):
        text = key
    try:
        return text.format(**values)
    except (KeyError, ValueError):
        return text


def tr_list(key: str) -> list[str]:
    value = _lookup(key, _strings)
    if value is None:
        value = _lookup(key, _fallback)
    return [str(item) for item in value] if isinstance(value, list) else []


def _system_font_candidates(language: str) -> list[str]:
    if language == "zh":
        return [
            "PingFang SC",
            "Hiragino Sans GB",
            "Heiti SC",
            "STHeiti",
            "Arial Unicode MS",
            "Microsoft YaHei",
            "SimHei",
            "Noto Sans CJK SC",
            "WenQuanYi Zen Hei",
        ]
    return ["Arial", "Helvetica", "DejaVu Sans", "Liberation Sans"]


def _find_font_name(language: str) -> str | None:
    installed_names = pygame.font.get_fonts()
    installed = {name.lower().replace(" ", ""): name for name in installed_names}
    for candidate in _system_font_candidates(language):
        key = candidate.lower().replace(" ", "")
        if key in installed:
            return installed[key]
    return None


def _make_base_font(language: str, bold: bool = False) -> pygame.font.Font:
    """Create the only native font size used by this module.

    Size 30 is already confirmed to render correctly on the user's Mac. Other
    requested sizes are created by scaling the rendered surface instead of
    asking SDL_ttf to rasterize the troublesome TTC font at those sizes.
    """
    font_name = _find_font_name(language)
    try:
        return pygame.font.SysFont(font_name, _SAFE_BASE_SIZE, bold=bold)
    except Exception:
        return pygame.font.Font(None, _SAFE_BASE_SIZE)


class ScaledFont:
    """Small compatibility wrapper exposing the pygame Font render API."""

    def __init__(self, base_font: pygame.font.Font, target_size: int):
        self._base_font = base_font
        self._target_size = max(1, int(target_size))
        self._scale = self._target_size / float(_SAFE_BASE_SIZE)

    def render(self, text, antialias, color, background=None):
        if background is None:
            surface = self._base_font.render(str(text), antialias, color)
        else:
            surface = self._base_font.render(str(text), antialias, color, background)

        if self._target_size == _SAFE_BASE_SIZE or surface.get_width() == 0:
            return surface

        width = max(1, round(surface.get_width() * self._scale))
        height = max(1, round(surface.get_height() * self._scale))
        return pygame.transform.smoothscale(surface, (width, height))

    def size(self, text):
        surface = self.render(text, True, (255, 255, 255))
        return surface.get_size()

    def get_height(self):
        return max(1, round(self._base_font.get_height() * self._scale))

    def get_linesize(self):
        return max(1, round(self._base_font.get_linesize() * self._scale))

    def set_bold(self, value):
        self._base_font.set_bold(value)

    def get_bold(self):
        return self._base_font.get_bold()


def create_font(size: int, bold: bool = False, language: str | None = None):
    selected_language = language or _language
    return ScaledFont(_make_base_font(selected_language, bold=bold), size)


def create_fonts(language: str | None = None):
    selected_language = language or _language
    return (
        create_font(30, language=selected_language),
        create_font(20, language=selected_language),
        create_font(48, bold=True, language=selected_language),
    )


set_language(_DEFAULT_LANGUAGE)
